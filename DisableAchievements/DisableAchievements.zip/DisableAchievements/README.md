# Disable Achievements

Very simple mod that has a single purpose of disabling the Achievements in-game menu option to prevent Steam from
popping up and stealing focus.
